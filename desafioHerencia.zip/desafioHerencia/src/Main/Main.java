package Main;

import familia.Familia;
import integrante.Integrante;
import servicios.FamiliaServicio;
import servicios.IntegranteServicio;

public class Main {
	public static void main(String[] args) {
		FamiliaServicio fs = new FamiliaServicio();
		IntegranteServicio is = new IntegranteServicio();
		
		Familia f1 = fs.crearFamilia();
		Integrante i1 = is.crearIntegrante();

		
		fs.agregarIntegrante(f1, i1);
		System.out.println(f1.getIntegrantes().toString());
		
	}
}
