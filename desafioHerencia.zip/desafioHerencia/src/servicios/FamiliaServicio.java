package servicios;

import java.util.ArrayList;
import java.util.Scanner;
import familia.FactorDeRiesgo;
import familia.Familia;
import familia.InformacionVivienda;
import familia.SinFactorDeRiesgo;
import integrante.Integrante;
import utilities.Paredes;
import utilities.Piso;

public class FamiliaServicio {
	public Familia crearFamilia() {
		Scanner sc = new Scanner(System.in);
			
		System.out.println("Ingrese la direccion");
		String direc = sc.next();
		System.out.println("Ingrese la ide");
		int ide = sc.nextInt();
		System.out.println("Ingrese el lote");
		int lote = sc.nextInt();
		System.out.println("Ingrese el barrio");
		String barrio = sc.next();
		System.out.println("Ingrese la Localidad");
		String local = sc.next();
		System.out.println("Ingrese la informacion de la vivienda");
		InformacionVivienda iv = new InformacionVivienda(3, Paredes.MATERIAL, Piso.CEMENTO, true);
		System.out.println("Ingrese 1 si tiene factor de riezgo, sino ingrese 2");
		int opc = sc.nextInt();
		
		switch (opc) {
		case 1: {
			System.out.println("Que factor de riezgo tiene?");
			ArrayList<Integer> factores = elegirFactores();
			FactorDeRiesgo fdr = new FactorDeRiesgo(direc,ide, lote, barrio,local, iv, factores);
			return fdr;
		}
		case 2: {
			System.out.println("Tiene alguna mejora?");
			boolean mejora = true;
			SinFactorDeRiesgo sfr = new SinFactorDeRiesgo(direc,ide, lote, barrio,local, iv, true);
			return sfr;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: ");
		}

	}

	public void agregarIntegrante(Familia f, Integrante i) {
		f.setIntegrantes(i);
	}
	
	public ArrayList<Integer> elegirFactores(){
		ArrayList<Integer> a = new ArrayList();
		a.add(1);
		a.add(2);
		a.add(3);
		
		return a;
	}
}
