package utilities;

public enum Paredes {
	MATERIAL,MADERA,LATA,OTRO;
}
