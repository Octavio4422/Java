package utilities;

public enum Vinculo {
	MADRE,PADRE,HIJO,HIJA,ABUELO,ABUELA;
}
