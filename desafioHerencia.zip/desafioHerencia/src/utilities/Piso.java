package utilities;

public enum Piso {
	MOSAICO,CEMENTO,TIERRA,OTRO;
}
